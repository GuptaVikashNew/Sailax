package P2;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginPage {

	public static void main(String[] args) throws InterruptedException {
		 WebDriver driver = new ChromeDriver();
         driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	        
	        driver.get("https://sailaxdbc.com/");
	        driver.findElement(By.xpath("//a[@class='login-btn-dbc active']")).click();
	        driver.findElement(By.xpath("//input[@type='email']")).sendKeys("krlsgupta1996@gmail.com");
	        driver.findElement(By.xpath("//input[@type='password']")).sendKeys("1234");
	       
	        driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@title='reCAPTCHA']")));
	        
	        Thread.sleep(5000);
	        driver.findElement(By.xpath("//div[@class='recaptcha-checkbox-border']")).click();
	        driver.switchTo().defaultContent();	
	        Thread.sleep(5000);
            driver.findElement(By.cssSelector("div[class='col-md-6 loginn-div']")).click();	
	}
}
