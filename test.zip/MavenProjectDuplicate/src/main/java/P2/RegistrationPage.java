package P2;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class RegistrationPage {
	
	public static void main(String[] args) throws InterruptedException {
		 WebDriver driver = new ChromeDriver();
		
         driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	        
	  driver.get("https://sailaxdbc.com/");
	  driver.findElement(By.xpath("//a[@class='login-btn-dbc active']")).click();
	  driver.findElement(By.xpath(" //span[text()='New user?']")).click();
	  driver.findElement(By.xpath("//input[@name='uName']")).sendKeys("Shiv");
	  driver.findElement(By.xpath("//input[@name='uEmail']")).sendKeys("abcpanda@yopmail.com");
	  WebElement selectbox =driver.findElement(By.xpath("//select[@class='form-control form-select select-cont']"));
	  
	  Select select = new Select(selectbox);
	  select.selectByIndex(100);
	  
	  driver.findElement(By.xpath("//input[@name='uMobile']")).sendKeys("9876543456");
	  driver.findElement(By.xpath("//input[@name='uPassword']")).sendKeys("8765");
	  
      // from here captcha operetion	  
	  driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@title='reCAPTCHA']")));
      
      Thread.sleep(5000);
      driver.findElement(By.xpath("//div[@class='recaptcha-checkbox-border']")).click();
      Thread.sleep(5000);
      driver.findElement(By.xpath("//input[@type='checkbox']")).click();
      driver.switchTo().defaultContent();	
      Thread.sleep(5000);
      
      driver.findElement(By.xpath(" //button[@id='registerSubmit']")).click();
   
	}

}
